NELL Knowledge graph in both triple format and PRA format.

NELL.08m.165.cesv.csv.p0.8.edges:
	NELL 165 in triple format.

edge_types,node_names,node_types,nodes.obj
	NELL 165 in PRAGraph format. 

relations:
	A manually created schema file for NELL version 165.

selected_relations:
	A set of relations with significant number of training instances.

conf
	A configuration file for running PRA.

Note: relations, selected_relations and conf should be present in PRA running folder.
