(Last updated 2010 July 30th)
This is the second version of Yeast data. 
It has extra information about Mesh heading, chemicals and affiliations etc.

There are two formats for this graph. Ghirl format (http://www.cs.cmu.edu/~wcohen/querendipity)
and Alchemy like format (http://alchemy.cs.washington.edu/).

[ghirl]
This folder contains data in the Ghirl format. One file is generated for each entity type.

[alchemy]
This folder contains data in the alchemy format.

[alchemy/schema] 
This file defines the argument type for each predicate.


[senario]
This file is used to generate training samples. Each row is a paper, with comma separated columnes 

representing fields in the paper, each of which is a white space seperated list of entities. 

[senario.title]
This file define the entity types for each column in the senario file


[The meaning of relations]

Cites: from one paper to another paper in its reference section
Gene: from one paper to genes mentioned in it
Aspect: from one paper to genes mentioned and the aspect of mention
Year: from one paper to its publication year
Journal: from one paper to the journal it is published in
Author: from one paper to its authors
AuthorF: from one paper to its first author
AuthorL: from one paper to its last author
Title: from one paper to its title words
Before: from one year to its previous year

Aff: affilication
Chem: chemical
DmHead: Mesh descriptor
QmHead: Mech qualifier


[Some detailed statistics]

There are 321K entities and 6.1M links. The nodes of our network are:
159k papers
29k headings
14k chemicals
5.6k genes
40k words
71k authors
1k journals
1.9k affiliations (selected from 6k affiliations)
62 years
