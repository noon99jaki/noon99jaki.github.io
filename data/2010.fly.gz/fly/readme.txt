(Last updated 2010 July 30th)

There are two formats for this graph. Ghirl format (http://www.cs.cmu.edu/~wcohen/querendipity)
and Alchemy like format (http://alchemy.cs.washington.edu/).

[ghirl]
This folder contains data in the Ghirl format. One file is generated for each entity type.

[alchemy]
This folder contains data in the alchemy format.

[alchemy/schema] 
This file defines the argument type for each predicate.


[senario]
This file is used to generate training samples. Each row is a paper, with comma separated columnes representing fields in the paper, each of which is a white space seperated list of entities. 

[senario.title]
This file define the entity types for each column in the senario file


[The meaning of relations]

Cites: from one paper to another paper in its reference section
Gene: from one paper to genes mentioned in it
Aspect: from one paper to genes mentioned and the aspect of mention
Year: from one paper to its publication year
Journal: from one paper to the journal it is published in
Author: from one paper to its authors
AuthorF: from one paper to its first author
AuthorL: from one paper to its last author
Title: from one paper to its title words
Before: from one year to its previous year

Protein: from one paper to proteins mentioned in it
Down: from one gene to its down stream imediate next gene on the DNA
genetic: one gene having genetic interaction with another gene
physical: one gene having physical interaction with another gene
GP: from one gene to the protein it produces


[Some detailed statistics]

PubMed is a free, open-access on-line archive of over 18 million biological abstracts and bibliographies, including citation lists, for papers published since 1948 (U.S. National Library of Medicine 2008). PubMed Central (PMC) contains full-text copies of over one million of these papers for which open access has been granted (National Institutes of Health 2008). 

Most of the data is extracted from the flymine database v20 (http://www.flymine.org/). Citation information is extracted from PubMed Central (PMC).

The nodes of our network are:
*	39,037 papers in PMC, 385,699 in total if cited papers are included
*	102,472  authors.
*	244,014  genes in flymine.
* 340,039 proteins in flymine.
*	58 years, from 1950 through 2009
*	376 journals
*	44,650  unique title terms, after applying a stop word list of size 429.

The edges of our network are
*	679,903 Citation relations.
*	550,458 physical/genetic interaction relations from genes to other genes.
*	679,903 Authorship relations from authors to the papers they authored. We further distinguish the relation to three types: any author, first author, and last author.
*	HasTitleTerm, InJorunal, InYear relations for each paper.
*	Before relations from each year to its next year.
*	26,432 downstream relations among genes.
